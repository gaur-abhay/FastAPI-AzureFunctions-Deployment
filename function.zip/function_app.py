import logging
import azure.functions as func
from azure.functions import AsgiMiddleware
from app.main import app  # Import existing FastAPI app

function_app = func.AsgiFunctionApp(app)


# Define an ASGI route
@function_app.route(route="/{*path}", auth_level=func.AuthLevel.ANONYMOUS, methods=["GET", "POST", "PUT", "DELETE"])
async def asgi_handler(req: func.HttpRequest, context: func.Context) -> func.HttpResponse:
    return await AsgiMiddleware(app).handle_async(req, context)
